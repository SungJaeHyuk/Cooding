﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using RestSharp;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;
namespace WindowsFormsApp1
{
    struct sub
    {
        public int pccnt;
        public int mobilecnt;
        public string s;
        public sub(string s1, int cnt1, int cnt2)
        {
            this.s = s1;
            this.pccnt = cnt1;
            this.mobilecnt = cnt2;
        }
    }
    public partial class Form1 : Form
    {
        List<sub> ans = new List<sub>();
        string s;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.DefaultExt = "txt";
            openFile.Filter = "txt Files(*.txt)|*.txt";
            openFile.ShowDialog();
            if (openFile.FileNames.Length > 0)
            {
                foreach (string filename in openFile.FileNames)
                {
                    s += filename;
                }
                textBox1.Text = Path.GetDirectoryName(s);
            }
        }
        void import(string s)
        {
            var baseUrl = ConfigurationManager.AppSettings["BASE_URL"];
            var apiKey = ConfigurationManager.AppSettings["API_KEY"];
            var secretKey = ConfigurationManager.AppSettings["SECRET_KEY"];
            var managerCustomerId = long.Parse(ConfigurationManager.AppSettings["CUSTOMER_ID"]);

            var rest = new SearchAdApi(baseUrl, apiKey, secretKey);

            var request = new RestRequest("/keywordstool", Method.GET);
            request.AddQueryParameter("hintKeywords", s);
            request.AddQueryParameter("includeHintKeywords", "1");
            request.AddQueryParameter("showDetail", "0");
            int A, B;
            List<CustomerLink> customerLinks = rest.Execute<List<CustomerLink>>(request, managerCustomerId, out A, out B);
            textBox2.Text = B.ToString();
            sub tmp = new sub(s, A, B);
            ans.Add(tmp);
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            StreamReader objReader = new StreamReader(s);
            string sline = "";
            int cnt = 0;
            ArrayList arrText = new ArrayList();
            while (sline != null)
            {
                sline = objReader.ReadLine();
                if (sline != null)
                {
                    import(sline);
                    cnt++;
                }
                if (cnt % 3 == 0) Thread.Sleep(600);
            }
            objReader.Close();
            textBox2.Text = ans.Count.ToString();
        }
        public static string GenerateCoupon(int length, Random random)
        {
            string characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            StringBuilder result = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                result.Append(characters[random.Next(characters.Length)]);
            }
            return result.ToString();
        }
        private void Save_Click(object sender, EventArgs e)
        {
            Excel.Workbook workbook = null;
            Excel.Worksheet worksheet = null;
            Excel.Application application = null;
            object missing = System.Reflection.Missing.Value;
            Random rnd = new Random();
            string random = GenerateCoupon(10, rnd);
            object fileName = Path.GetDirectoryName(s) + @"\" + random + ".xlsx";
            application = new Excel.Application();
            application.Visible = false;
            application.DisplayAlerts = false;
            application.Interactive = false;
            workbook = application.Workbooks.Add(missing);
            worksheet = (Excel.Worksheet)workbook.Sheets["Sheet1"];
            worksheet.Cells[1, 2] = "Item";
            worksheet.Cells[1, 3] = "PCCnt : ";
            worksheet.Cells[1, 4] = "MobileCnt : ";
            int cnt = 2;
            for(int i=0;i<ans.Count;i++)
            {
                worksheet.Cells[cnt, 2] = ans[i].s;
                worksheet.Cells[cnt, 3] = ans[i].pccnt;
                worksheet.Cells[cnt, 4] = ans[i].mobilecnt;
                cnt++;
            }
            workbook.SaveAs(fileName);
            workbook.Close();
            application.Quit();
            ReleaseExcelobject(workbook);
            ReleaseExcelobject(worksheet);
            ReleaseExcelobject(application);
            MessageBox.Show("Success");
        }
        public static void ReleaseExcelobject(object obj)
        {
            try
            {
                if(obj!=null)
                {
                    Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception Ex)
            {
                obj = null;
                throw Ex;
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
